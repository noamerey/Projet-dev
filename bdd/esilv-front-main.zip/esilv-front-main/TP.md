# TP1
## Consignes

Créer un gestionnaire de liste de tâches
- Pouvoir lister un ensemble de tâches (cf Technical Details)
- Pouvoir ajouter une tâche
- Pouvoir passer une tâche en completed ou inversement en cliquant dessus
- Pouvoir modifier complêtement une tâche
- Pouvoir supprimer une tâche

## Technical details

Tâche:
- un titre (string)
- un status (bool)
- une date (date)
- un id unique (int)

## Bonus
- Pouvoir filtrer les tâches par status et titre
- Grouper les tâches par status (completed en bas et non completed en haut)